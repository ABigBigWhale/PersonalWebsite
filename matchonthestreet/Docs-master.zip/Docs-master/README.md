# Match on the Street Docs
The repository storing documentations on the development of Match on the Street project.

See the [User Guide](https://github.com/MatchOnTheStreet/Docs/blob/master/UserGuide.md) and [Developer Guide](https://github.com/MatchOnTheStreet/Docs/blob/master/DeveloperGuide.md) for details.
